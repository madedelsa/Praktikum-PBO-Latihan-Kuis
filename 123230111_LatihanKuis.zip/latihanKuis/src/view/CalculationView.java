package view;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.SisiMiring;

public class CalculationView extends JFrame {
    public CalculationView() {
        setTitle("Hitung Siku");
        setSize(300, 200);
        setLayout(null);

        JLabel lAlas = new JLabel("Nilai Alas:");
        JTextField fAlas = new JTextField();
        JLabel lTinggi = new JLabel("Nilai Tinggi:");
        JTextField fTinggi = new JTextField();
        JButton bHitung = new JButton("Hitung");

        lAlas.setBounds(20, 20, 80, 25);
        fAlas.setBounds(100, 20, 150, 25);
        lTinggi.setBounds(20, 60, 80, 25);
        fTinggi.setBounds(100, 60, 150, 25);
        bHitung.setBounds(100, 100, 100, 25);

        add(lAlas);
        add(fAlas);
        add(lTinggi);
        add(fTinggi);
        add(bHitung);

        bHitung.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    float alas = Float.parseFloat(fAlas.getText());
                    float tinggi = Float.parseFloat(fTinggi.getText());
                    SisiMiring sm = new SisiMiring(alas, tinggi);
                    float hasil = sm.hitungSisiMiring();
                    JOptionPane.showMessageDialog(null, "Sisi miring adalah: " + hasil);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Input tidak valid. Masukkan angka.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        setVisible(true);
    }
}