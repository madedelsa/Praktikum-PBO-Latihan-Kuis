package view;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import model.User;

public class LoginView extends JFrame {
    private JLabel lUsername = new JLabel("Username:");
    private JTextField fUsername = new JTextField();
    private JLabel lPassword = new JLabel("Password:");
    private JPasswordField fPassword = new JPasswordField();
    private JButton bLogin = new JButton("Login");
    private int attempts = 3;

    public LoginView() {
        setTitle("Login Form");
        setSize(300, 200);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        lUsername.setBounds(20, 20, 80, 25);
        fUsername.setBounds(100, 20, 150, 25);
        lPassword.setBounds(20, 60, 80, 25);
        fPassword.setBounds(100, 60, 150, 25);
        bLogin.setBounds(100, 100, 100, 25);

        add(lUsername);
        add(fUsername);
        add(lPassword);
        add(fPassword);
        add(bLogin);

        bLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = fUsername.getText();
                String password = new String(fPassword.getPassword());

                User user = new User(username, password);
                user.doValidation();

                if (user.isLogin()) {
                    JOptionPane.showMessageDialog(null, "Login berhasil! Selamat datang, " + username);
                    new CalculationView().setVisible(true);
                    dispose(); // Menutup jendela login setelah berhasil
                } else {
                    attempts--;
                    if (attempts > 0) {
                        JOptionPane.showMessageDialog(null, "Login gagal! Periksa username dan kata sandi. Sisa kesempatan: " + attempts, "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Kesempatan habis! Program akan ditutup.", "Error", JOptionPane.ERROR_MESSAGE);
                        System.exit(0);
                    }
                }
            }
        });
    }
}