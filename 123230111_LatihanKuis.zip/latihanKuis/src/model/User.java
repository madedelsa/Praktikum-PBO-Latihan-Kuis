package model;

public class User {
    private String username;
    private String password;
    private boolean login = false;

    // Constructor untuk menerima input username dan password
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public void doValidation() {
        if ("tukang_111".equals(username) && "tukang_111".equals(password)) {
            login = true;
        } else {
            login = false;
        }
    }

    // Getter untuk status login
    public boolean isLogin() {
        return login;
    }
}