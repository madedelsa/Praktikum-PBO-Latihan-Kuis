package model;

public class SisiMiring {
    private float alas, tinggi;

    public SisiMiring(float alas, float tinggi){
        this.alas = alas;
        this.tinggi = tinggi;
    }

    public float hitungSisiMiring(){
        float sisiMiring = (float) Math.sqrt(Math.pow(alas, 2) + Math.pow(tinggi, 2));
        return sisiMiring;
    }
}